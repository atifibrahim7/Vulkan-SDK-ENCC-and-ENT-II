#ifndef ENTT_COMMON_CUSTOM_ENTITY_H
#define ENTT_COMMON_CUSTOM_ENTITY_H

#include <cstdint>

namespace test {

enum custom_entity : std::uint32_t {};

} // namespace test

#endif
