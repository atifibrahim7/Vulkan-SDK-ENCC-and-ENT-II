#ifndef ENTT_COMMON_EMPTY_H
#define ENTT_COMMON_EMPTY_H

namespace test {

struct empty {};

} // namespace test

#endif
